﻿using System;
using System.Threading;

namespace Day29
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread ob = Thread.CurrentThread;
            ob.Name = "MainExample Thread";
            Console.WriteLine("Thread name = "+ob.Name);
        }
    }
}
