﻿using System;
using System.Threading;

namespace Day29
{
    class Mythread3
    {
        public void showme(object x)
        {
            int n = 0;
            if(int.TryParse(x.ToString(),out n))
            {
                for (int i = 0; i < n; i++)
                    Console.WriteLine(Thread.CurrentThread.Name + "  " + i);
            }            
        }
    }
    class Thread4
    {
        static void Main(string[] args)
        {
            object n;
            Console.WriteLine("Enter the value of n");
            n =Console.ReadLine();

            object n2;
            Console.WriteLine("Enter the value of n");
            n2 = Console.ReadLine();

            Mythread3 ob = new Mythread3();
            ParameterizedThreadStart pa = new ParameterizedThreadStart(ob.showme);

            Thread t = new Thread(pa);
            t.Name = "Parameterized thread";
            t.Start(n);
            
            Thread t2 = new Thread(pa);
            t2.Name = "Parameterized thread1";
            t2.Start(n2);
        }
    }
}
