﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Day29
{
    class Num
    {
        private int num;

        public Num(int n)
        {
            num = n;
        }
        public void showme()
        {
            for(int i =0;i<num;i++)
                Console.WriteLine(i);
        }
    }
    class Thread5
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the parameter");
            int n = int.Parse(Console.ReadLine());

            Num ob = new Num(n);

            Thread ob1 = new Thread(ob.showme);
            ob1.Start();
        }
    }
}
