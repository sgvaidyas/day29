﻿using System;
using System.Threading;

namespace Day29
{
    class MyThread6
    {
        public void fun()
        {
            for(int i=0;i<20;i++)
            {
                Console.WriteLine(Thread.CurrentThread.Name + " " + i);
                Thread.Sleep(200);
            }
        }
    }
    
    class Thread6cs
    {
        static void Main(string[] args)
        {
            MyThread6 ob = new MyThread6();

            Thread t1 = new Thread(ob.fun);
            Thread t2 = new Thread(ob.fun);
            Thread t3 = new Thread(ob.fun);

            t1.Name = "One";
            t2.Name = "Two";
            t3.Name = "Three";

            t1.Start();
            t2.Start();
            t3.Start();
        }
    }
}
