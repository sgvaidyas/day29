﻿using System;
using System.Threading;

namespace Day29
{
    public  delegate  void fact(int val);

    class Factorial
    {
        private int num;
        fact callback;

        public Factorial(int num,fact f)
        {
            this.num = num;
            callback = f;
        }
        public void calfact()
        {
            int res = 1;
            for (int i = 1; i <= num; i++)
                res *= i;

            if (callback != null)
                callback(res);
        }
    }
       
    class Thread7
    {
        public static void printfact(int res)
        {
            Console.WriteLine("Print factorial = "+res);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the parameter");
            int num = int.Parse(Console.ReadLine());

            fact call = new fact(printfact);

            Factorial ob = new Factorial(num,call);

            // Thread d = new Thread(new ThreadStart(ob.calfact));
            Thread d = new Thread(() => ob.calfact());
            d.Start();
        }
    }
}
