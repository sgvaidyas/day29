﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
namespace Day29
{
    class Thread8
    {
        static void Main(string[] args)
        {
            Mythread2 ob = new Mythread2();
            Thread t1 = new Thread(ob.myfun);
            Thread t2 = new Thread(ob.myfun);
            Thread t3 = new Thread(ob.myfun);
            t1.Name = "One";
            t2.Name = "Two";
            t3.Name = "three";
            t3.Priority = ThreadPriority.Highest;
            t1.Priority = ThreadPriority.Lowest;
            t2.Priority = ThreadPriority.Normal;

            t1.Start();
            t2.Start();
            t3.Start();
        }
    }
}
