﻿using System;
using System.Threading;

namespace Day29
{
    class MyThread1
    {
        public static void Threadfun()
        {
            for(int i=0;i<20;i++)
                Console.WriteLine(Thread.CurrentThread.Name + " __________  "   +i);
        }
    }
    class Threads2
    { 
        static void Main(string[] args)
        {
            Thread t1 = new Thread(new ThreadStart(MyThread1.Threadfun));
            Thread t2 = new Thread(new ThreadStart(MyThread1.Threadfun));
            t1.Name = "One";
            t2.Name = "Two";
            t1.Start();
            t2.Start();
        }
    }
}
