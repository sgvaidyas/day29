﻿using System;
using Logicalproblems;

namespace ImplementationLib
{
    class Program
    {
        static void Main(string[] args)
        {
            SumofNaturalnum ob = new SumofNaturalnum();
            Console.WriteLine("Enter any num");
            int n = int.Parse(Console.ReadLine());
            int res = ob.Addnum(n);
            Console.WriteLine("Sum of n num = " + res);
        }
    }
}
